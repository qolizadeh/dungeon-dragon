from sqlalchemy import *
from sqlalchemy.ext.declarative import *
from sqlalchemy.orm import *

database_instance = 0

class database():

    db_conn_string = 'postgresql+psycopg2://postgres:123456@127.0.0.1:5432/postgres'
    engine = create_engine(db_conn_string, echo = False)

    def getSession(self):        
        return sessionmaker(bind=self.engine)()    

    @staticmethod
    def getInstance():
        global database_instance
        if  not isinstance(database_instance, database):
            database_instance = database()

        return database_instance


