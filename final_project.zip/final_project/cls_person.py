from datalayer import *

class cls_person():

    @staticmethod
    def create_person(username, password, name, melicode):
        if isinstance(DL_person.create_person(username, password, name, melicode), Person):
            return True
        return False

    @staticmethod
    def get_all_persons():
        data = DL_person.get_all_persons()
        for x in data:
            del x.__dict__["_sa_instance_state"]
        return [x.__dict__ for x in data]
        