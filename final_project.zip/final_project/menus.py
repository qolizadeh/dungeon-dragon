from decorators import *
from logger import *
from decorators import *
from cls_person import *

import sys

class base:
    menu_code = 0

    def run(self, *args, **kwargs):
        pass

class register(base):    

    def __init__(self):
        self.menu_code = 1

    def run(self):
            username = input("enter username:")
            password = input("enter password:")
            melicode = input("enter melicode:")
            name = input("enter name:")
            cls_person.create_person(username, password, name, melicode)
            cls_report.report("new person made")

    @not_authenticated_user_str
    def __str__(self):
        return "register"

class login(base):    

    def __init__(self):
        self.menu_code = 2

    def run(self):
        username = input("enter username:")
        #todo decorator for check policy
        password = input("enter password:")
        #todo decorator for check policy
        authentication.getInstance().login(username, password) 
        if authentication.getInstance().is_loggedin():
            cls_report.report("logged in")
        else:
            cls_report.report("logged in failed.")

    @not_authenticated_user_str
    def __str__(self):
        return "login"

class logout(base):    

    def __init__(self):
        self.menu_code = 3

    def run(self):
        if authentication.getInstance().is_loggedin():
            current_person = authentication.getInstance().get_person()
            data1 = cls_person.get_all_persons()
            dict_to_json_file("{}_personels.json".format(current_person.username), data1)
            # data2 = cls_report.get_all_reports()
            # dict_to_json_file(f"{current_person.username}_reports.json", data2)
            if authentication.getInstance().logout():
                cls_report.report("logouted")

    @authenticated_user_str
    def __str__(self):
        return "logout"

class profile(base):    
    def __init__(self):
        self.menu_code = 4

    @authenticated_user
    def run(self) :        
        current_person = authentication.getInstance().get_person()
        print("login status: {}".format(current_person.login))
        print("melicode: {}".format(current_person.melicode))
        print("name: {}".format(current_person.name))
        print("username: {}".format(current_person.username))

    @authenticated_user_str
    def __str__(self):
        return "profile"


class quiz(base) :  
    def __init__(self):
        self.menu_code = 5

    @authenticated_user
    def run(self) :
        print("quiz game executed...")

    @authenticated_user_str
    def __str__(self):
        return "quiz"


class dungeon_game(base):    

    def __init__(self):
        self.menu_code = 6

    def __str__(self):
        return "dungeon_game"


class exit_program(base):    

    def __init__(self):
        self.menu_code = 10

    def run(self):
        authentication.getInstance().logout()
        sys.exit(0)

    def __str__(self):
        return "exit"
