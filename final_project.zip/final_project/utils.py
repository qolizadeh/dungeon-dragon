import hashlib
import json

def get_hash(input_string):
    md5 = hashlib.md5()
    md5.update(input_string.encode('utf-8') )
    return md5.hexdigest()


def dict_to_json_file(filename, data):
    with open(filename, 'w') as fp:
        json.dump(data, fp)