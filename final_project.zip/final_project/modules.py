from sqlalchemy import *
from sqlalchemy.ext.declarative import *
from sqlalchemy.orm import *

Base = declarative_base()

class Person(Base):
    __tablename__ = 'person'
    TABLE_ID = Sequence('person_id_seq', start=1000)

    id = Column(Integer, TABLE_ID, primary_key=True, server_default=TABLE_ID.next_value())
    username = Column(String, primary_key = True)
    password = Column(String, nullable=False)
    melicode = Column(String, nullable=False)
    name = Column(String, nullable=False)
    login = Column(Integer, nullable=False)

class Logger(Base) :
    __tablename__ = 'logger'
    TABLE_ID = Sequence('logger_id_seq', start=1000)
    id = Column(Integer, TABLE_ID, primary_key=True, server_default=TABLE_ID.next_value())
    activity = Column(String, nullable=False)
    DateTime = Column(DateTime, nullable=False)
    person_id = Column(Integer, nullable=False)
    #person = relationship(Person)

if __name__ == "__main__":
    db_conn_string = 'postgresql+psycopg2://postgres:123456@127.0.0.1:5432/postgres'
    engine = create_engine(db_conn_string, echo = False)    
    Base.metadata.create_all(engine)