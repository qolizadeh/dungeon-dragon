from sqlalchemy import *
from sqlalchemy.ext.declarative import *
from sqlalchemy.orm import *
from datetime import *
from modules import *
from database import *
from utils import *


class DL_person():
    @staticmethod
    def create_person(username,  password, name, melicode):
        session = database.getInstance().getSession()

        new_person = Person()
        new_person.username = username
        new_person.password = get_hash(password)
        new_person.name = name
        new_person.melicode = melicode
        new_person.login = 0

        session.add(new_person)
        session.commit()        
        return new_person

    @staticmethod
    def get_all_persons():
        session = database.getInstance().getSession()
        return session.query(Person).all()

class DL_authenticate():

    @staticmethod
    def login(username, password) :   
        session = database.getInstance().getSession()
        t_person = session.query(Person).filter(Person.username == username).filter(Person.password == get_hash(password)).first()
        if not isinstance(t_person, Person):
            return None
        t_person.login = 1
        session.commit()
        return t_person

    @staticmethod
    def logout(current_person) :        
        session = database.getInstance().getSession()     
        t_person = session.query(Person).filter(Person.id == current_person.id).first()
        if isinstance(t_person, Person):
            t_person.login = 0
            session.commit()
            return True
        return False

class DL_reporter():

    @staticmethod
    def report(person_id, activity):
        session = database.getInstance().getSession()

        new_log = Logger()
        new_log.activity = activity
        new_log.person_id = person_id
        new_log.DateTime = datetime.now()
        session.add(new_log)
        session.commit()        

    @staticmethod
    def get_all_reports():
        session = database.getInstance().getSession()
        return session.query(Logger).all()
