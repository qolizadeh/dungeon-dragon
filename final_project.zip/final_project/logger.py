from datalayer import *
from modules import *
from authentication import *

class cls_report():

    @staticmethod
    def report(activity):
        if authentication.getInstance().is_loggedin():
            current_person = authentication.getInstance().get_person()    
            if isinstance(current_person, Person):
                print("{} {}".format(current_person.name,activity))
                DL_reporter.report(current_person.id, activity)
        else:
            print("{}".format(activity))
            DL_reporter.report(0, activity)

    @staticmethod
    def get_all_reports():
        data = DL_reporter.get_all_reports()
        for x in data:
            del x.__dict__["_sa_instance_state"]
        return [x.__dict__ for x in data]


