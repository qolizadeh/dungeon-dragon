from menus import *
from logger import *


def print_menus(all_classes):
    for obj in all_classes:
        if(len(str(obj)) > 0):
            print(obj.menu_code, "- ", obj)

def choose_menu():
    all_classes = [register(), login(), logout(), profile(), quiz(), dungeon_game(), exit_program()]
    print_menus(all_classes)
    msg = input("choose item:")
    if not msg.isdigit():
        return True
    item = int(msg)
    for obj in all_classes:
        if(obj.menu_code == item):
            cls_report.report("{} executed".format(str(obj)))
            obj.run()
    return True

if __name__ == "__main__":
    while(choose_menu()):
        pass







