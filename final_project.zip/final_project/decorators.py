from authentication import *

def authenticated_user(func):
    def wrapper(*args, **kwargs):
        if authentication.getInstance().is_loggedin():
            return func(*args, **kwargs)        
    return wrapper

def not_authenticated_user_str(func):
    def wrapper(*args, **kwargs):
        if not authentication.getInstance().is_loggedin():
            return func(*args, **kwargs) 
        else:
            return ""
    return wrapper


def authenticated_user_str(func):
    def wrapper(*args, **kwargs):
        if authentication.getInstance().is_loggedin():
            return func(*args, **kwargs) 
        else:
            return ""
    return wrapper
