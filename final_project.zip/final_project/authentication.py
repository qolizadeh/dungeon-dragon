from datetime import *
from modules import *
from datalayer import *

auth = 0

class authentication():    

    current_person = Person()

    def logout(self):
        if isinstance(self.current_person, Person):
            if DL_authenticate.logout(self.current_person):
                self.current_person = Person()
                return True
        return False

    def get_person(self):
        return self.current_person

    def login(self, username, password):
        self.current_person = DL_authenticate.login(username, password) 
        if isinstance(self.current_person, Person):
            if self.current_person.login == 1:
                return True
        return False

    def is_loggedin(self):
        if(isinstance(self.current_person, Person) and self.current_person.login == 1) :
            return True
        return False

    @staticmethod
    def getInstance():
        global auth
        if  not isinstance(auth, authentication):
            auth = authentication()
        return auth


    def __str__(self):
        return "logout" if isinstance(self.get_person(), Person)  and self.get_person().login == 1 else "login"
